extern void cubeTest();
extern void sphereTest();
extern void sphereTest2();
extern void cubeTexTest();
extern void guiTest();
extern void quadTest();
extern void particleTest();
extern void spriteTest();
extern void cubeMapText();
extern void pickColorTest();
extern void renderToFrameBufferTest();
extern void objTest();
extern void spritesBatchTest();
extern void drawLineTest();
extern void polygonOffsetTest();
extern void vertexAttributeTest();
extern void customMeshLayoutTest();
extern void customMeshLayoutDefaultValuesTest();
extern void textureTest();
extern void multiCameraTest();
extern void screePointToRayTest();

int main()
{
    screePointToRayTest();
    return 0;
}
