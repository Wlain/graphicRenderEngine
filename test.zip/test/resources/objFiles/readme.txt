Most models are from AssImp https://github.com/assimp/assimp/tree/master/test/models/OBJ
